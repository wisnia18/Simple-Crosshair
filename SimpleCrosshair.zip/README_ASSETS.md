# Instrukcja folderu assets

Ten folder służy do ładowania Twoich własnych, autorskich plików graficznych i dźwiękowych do aplikacji **Simple Crosshair**. Program automatycznie je wykryje po uruchomieniu.

## Dozwolone pliki i nazewnictwo:

### 1. Własne celowniki graficzne (Obrazki PNG)
Możesz wgrać maksymalnie 4 własne grafiki. Upewnij się, że pliki mają przezroczyste tło.
- **`cross1.png`** - Nadpisuje niestandardowy celownik nr 1
- **`cross2.png`** - Nadpisuje niestandardowy celownik nr 2
- **`cross3.png`** - Nadpisuje niestandardowy celownik nr 3
- **`cross4.png`** - Nadpisuje niestandardowy celownik nr 4

### 2. Dźwięki (Pliki WAV)
Aplikacja może odtwarzać efekty dźwiękowe. Pliki muszą być zapisane w formacie `.wav`.
- **`click.wav`** - Dźwięk odtwarzany podczas klikania elementów interfejsu (UI).
- **`shoot.wav`** - Opcjonalny dźwięk strzału, reagujący na lewy przycisk myszy.

Po wrzuceniu odpowiednich plików do tego folderu, włącz/zrestartuj aplikację, a nowe efekty będą gotowe do użycia!
